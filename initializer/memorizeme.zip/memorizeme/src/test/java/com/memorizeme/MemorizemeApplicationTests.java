package com.memorizeme;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MemorizemeApplicationTests {

	@Test
	void contextLoads() {
	}

}
