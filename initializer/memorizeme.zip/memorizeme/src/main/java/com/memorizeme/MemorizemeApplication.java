package com.memorizeme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MemorizemeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MemorizemeApplication.class, args);
	}

}
